<?php

/**
 * Internationalization
 *
 * Copyright 2020 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

$xpdo_meta_map = [
    'xPDOSimpleObject' => [
        'InternationalizationResource'
    ]
];
