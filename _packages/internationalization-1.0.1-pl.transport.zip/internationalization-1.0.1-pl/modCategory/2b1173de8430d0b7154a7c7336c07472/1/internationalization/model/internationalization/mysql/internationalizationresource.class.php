<?php

/**
 * Internationalization
 *
 * Copyright 2020 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/internationalizationresource.class.php';

class InternationalizationResource_mysql extends InternationalizationResource
{
}
